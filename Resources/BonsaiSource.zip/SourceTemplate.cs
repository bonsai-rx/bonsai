﻿using Bonsai;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// TODO: replace this with the source output type.
using TSource = System.String;

namespace $rootnamespace$
{
    public class $safeitemname$ : Source<TSource>
    {
        protected override IObservable<TSource> Generate()
        {
            // TODO: generate the observable sequence.
            throw new NotImplementedException();
        }
    }
}
